<?php

require_once '../src/Model/Model.php';
require_once '../src/entity/PanierEntity.php';

class PanierRepository{

    // Attributs

    protected array $paniers;
    protected Model $model;

    public function __construct()
    {
        $this->model = new Model();
    }

    // Méthodes

    public function chargementPanier() 
    {
        $req = $this->model->getBdd()->prepare("SELECT * FROM panier");
        $req->execute();
        $mesPaniers = $req->fetchAll(PDO::FETCH_ASSOC);

        foreach($mesPaniers as $panier){ 
            $this->paniers[] = new PanierEntity($panier['id'], $panier['musiques'], $panier['quantites'], $panier['id_user']);
        }
    }

    /**
     * get the value of the basket by user id
     *
     * @param integer $id_user
     * @return void
     */
    public function getPanierbyUserId(int $id_user)
    {
            $existe = false;
            for($i=0; $i<count($this->paniers); $i++){
                if($this->paniers[$i]->getId_user() == $id_user){
                    $index = $i;    
                    $existe = true;
                }
            }
            if($existe){
                return $this->paniers[$index];
            }else{
                require "views/404.php";
                return false;
            }
    }

    /**
     * method which add the basket in the database
     *
     * @param string $musiques
     * @param string $quantites
     * @param integer $id_user
     * @return void
     */
    public function ajoutPanierBd(string $musiques, string $quantites, int $id_user){
        $req = "INSERT INTO panier (musiques, quantites, id_user)
        values (:musiques, :quantites, :id_user)";
        $statement = $this->model->getBdd()->prepare($req);
        $statement->bindValue(":musiques",$musiques,PDO::PARAM_STR); // Parametre permet un peu plus de securité
        $statement->bindValue(":quantites",$quantites,PDO::PARAM_STR);
        $statement->bindValue(":id_user",$id_user,PDO::PARAM_INT);
        $resultat = $statement->execute();
        $statement->closeCursor();
        if($resultat > 0){
            $panier = new PanierEntity($this->model->getBdd()->lastInsertId(), $musiques, $quantites, $id_user);
            $this->paniers[] = $panier;
            return $panier;
        }
    }

    /**
     * method which edit/change the user in the database
     *
     * @param string $musiques
     * @param string $quantites
     * @param integer $id
     * @return void
     */
    public function modifPanierBD(string $musiques, string $quantites, int $id){
        $req ="
        UPDATE panier
        set musiques = :musiques, quantites = :quantites
        where id = :id";
        $statement = $this->model->getBdd()->prepare($req);
        $statement->bindValue(":id",$id,PDO::PARAM_INT);
        $statement->bindValue(":musiques",$musiques,PDO::PARAM_STR); // Parametre permet un peu plus de securité
        $statement->bindValue(":quantites",$quantites,PDO::PARAM_STR);
        $resultat = $statement->execute();
        $statement->closeCursor();
    }


    /**
     * Get the value of paniers
     */ 
    public function getPaniers()
    {
        return $this->paniers;
    }
}

?>