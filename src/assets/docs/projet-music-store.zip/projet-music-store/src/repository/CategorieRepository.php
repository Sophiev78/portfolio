<?php

require_once '../src/Model/Model.php';
require_once '../src/entity/CategorieEntity.php';


class CategorieRepository{

    // Attributs

    protected array $categories;
    protected Model $model;

    // Constructeur

    public function __construct()
    {
        $this->model = new Model();
    }

    // Méthodes

    public function chargementCategories() 
    {
        $req = $this->model->getBdd()->prepare("SELECT * FROM categories");
        $req->execute();
        $mesCategories = $req->fetchAll(PDO::FETCH_ASSOC);

        foreach($mesCategories as $categorie){ 
            $this->categories[] = new CategorieEntity($categorie['id_cat'],$categorie['nom_cat']);
        }
    }

    public function getCategorieById(int $id): CategorieEntity
    {
        try{
            $existe = false;
            for($i=0;$i<count($this->categories); $i++){
                if($this->categories[$i]->getIdCat() == $id){
                    $index = $i;
                    $existe = true;
                }
            }
            if($existe){
                return $this->categories[$index];
            }else{
                require "views/404.php";
                throw new Exception("La categorie demandé n'existe pas !");
            }
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    //Admin

    public function ajoutCategorieBd(string $nom_cat){ // CREATE
        $req = "
        INSERT INTO categories (nom_cat)
        values(:nom_cat)"; // bind values Permet de sécuriser les infos transmises par la requete
        $statement = $this->model->getBdd()->prepare($req);
        $statement->bindValue(":nom_cat",$nom_cat,PDO::PARAM_STR); // Parametre permet un peu plus de securité
        $resultat = $statement->execute();
        $statement->closeCursor();

        if($resultat > 0){ // Si la req a aboutit
            $categorie = new CategorieEntity($this->model->getBdd()->lastInsertId(), $nom_cat);
            $this->categories[] = $categorie;
        }
    }

    public function suppressionCategorieBd(int $id){ // SUPPR
        $req="
        DELETE from categories where id_cat = :id_cat";
        $statement = $this->model->getBdd()->prepare($req);
        $statement->bindValue(":id_cat",$id,PDO::PARAM_INT);
        $resultat = $statement->execute();
        $statement->closeCursor();

        if($resultat > 0){ // Si la req a aboutit
            $categorie = $this->getCategorieById($id);
            unset($categorie);
        }
    }

    public function modifCategorieBd(int $id, string $nom_cat){ // UPDATE
        $req ="
        UPDATE categories
        set nom_cat = :nom_cat
        where id_cat = :id_cat";
        $statement = $this->model->getBdd()->prepare($req);
        $statement->bindValue(":id_cat",$id,PDO::PARAM_INT); // Parametre permet un peu plus de securité
        $statement->bindValue(":nom_cat",$nom_cat,PDO::PARAM_STR); 
        $resultat = $statement->execute();
        $statement->closeCursor();

        if($resultat > 0){
            $this->getCategorieById($id)->setNomCat($nom_cat);
        }
    }


    // getteurs

    public function getCategories() : array // recupère le tableau de categories rempli
    { 
        return $this->categories;
    }

}
