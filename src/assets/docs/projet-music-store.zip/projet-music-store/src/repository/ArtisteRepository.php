<?php

require_once '../src/Model/Model.php';
require_once '../src/entity/ArtisteEntity.php';


    class ArtisteRepository{

    // Attributs

    protected array $artistes;
    protected Model $model;

    /**
     * class which takes the BDD for the crud
     */
    public function __construct()
    {
        $this->model = new Model();
    }

    // Méthodes

    /**
     * method which show the artists to the store view
     *
     * @return void
     */
    public function chargementArtistes() 
    {
        $req = $this->model->getBdd()->prepare("SELECT * FROM artistes");
        $req->execute();
        $mesArtistes = $req->fetchAll(PDO::FETCH_ASSOC);

        foreach($mesArtistes as $artiste){ 
            $this->artistes[] = new ArtisteEntity($artiste['id_artiste'],$artiste['nom_artiste']);
        }
    }

    /**
     * method which get the id of the artists to the store view
     *
     * @param integer $id
     * @return ArtisteEntity
     */
    public function getArtisteById(int $id): ArtisteEntity
    {
        try{
            $existe = false;
            for($i=0;$i<count($this->artistes); $i++){
                if($this->artistes[$i]->getIdArtiste() == $id){
                    $index = $i;
                    $existe = true;
                }
            }
            if($existe){
                return $this->artistes[$index];
            }else{
                require "views/404.php";
                throw new Exception("La musique demandé n'existe pas !");
            }
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    //Admin

    /**
     * method which add the artists in the database
     *
     * @param string $nom_artiste
     * @return void
     */
    public function ajoutArtisteBd(string $nom_artiste){ // CREATE
        $req = "
        INSERT INTO artistes (nom_artiste)
        values(:nom_artiste)"; // bind values Permet de sécuriser les infos transmises par la requete
        $statement = $this->model->getBdd()->prepare($req);
        $statement->bindValue(":nom_artiste",$nom_artiste,PDO::PARAM_STR); // Parametre permet un peu plus de securité
        $resultat = $statement->execute();
        $statement->closeCursor();

        if($resultat > 0){ // Si la req a aboutit
            $artiste = new ArtisteEntity($this->model->getBdd()->lastInsertId(), $nom_artiste);
            $this->artistes[] = $artiste;
        }
    }

    /**
     * method which delete the artists from the database
     * @param integer $id
     * @return void
     */
    public function suppressionArtisteBd(int $id){ // SUPPR
        $req="
        DELETE from artistes where id_artiste = :id_artiste";
        $statement = $this->model->getBdd()->prepare($req);
        $statement->bindValue(":id_artiste",$id,PDO::PARAM_INT);
        $resultat = $statement->execute();
        $statement->closeCursor();

        if($resultat > 0){ // Si la req a aboutit
            $artiste = $this->getArtisteById($id);
            unset($artiste);
        }
    }

    /**
     * method which edit/change the artists from the database
     *
     * @param integer $id
     * @param string $nom_artiste
     * @return void
     */
    public function modifArtisteBd(int $id, string $nom_artiste){ // UPDATE
        $req ="
        UPDATE artistes
        set nom_artiste = :nom_artiste
        where id_artiste = :id_artiste";
        $statement = $this->model->getBdd()->prepare($req);
        $statement->bindValue(":id_artiste",$id,PDO::PARAM_INT); // Parametre permet un peu plus de securité
        $statement->bindValue(":nom_artiste",$nom_artiste,PDO::PARAM_STR); 
        $resultat = $statement->execute();
        $statement->closeCursor();

        if($resultat > 0){
            $this->getArtisteById($id)->setNomArt($nom_artiste);
        }
    }


    /**
     * get the value of the artists
     *
     * @return void
     */
    public function getArtistes() : array // recupère le tableau des artistes rempli
    { 
        return $this->artistes;
    }

}