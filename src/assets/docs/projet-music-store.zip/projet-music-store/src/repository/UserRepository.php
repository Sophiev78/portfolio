<?php

require_once '../src/Model/Model.php';
require_once '../src/entity/UserEntity.php';

class UserRepository{ // héritage de class Model (connexion BDD)

    // attributs

    protected array $users = array();
    protected Model $model;

    public function __construct(){
        $this->model = new Model();
    }

    //Méthodes

    /**
     * method which load the users
     *
     * @return void
     */
    public function chargementUsers(){
        $req = $this->model->getBdd()->prepare("SELECT * FROM user");
        $req->execute();
        $mesUsers = $req->fetchAll(PDO::FETCH_ASSOC); 
        $req->closeCursor();

        foreach($mesUsers as $user){ 
            $this->users[]= new UserEntity($user['id_user'],$user['email_user'],$user['pwd_user']);
        }
    }

    /**
     * get the value of the user's email 
     *
     * @param string $email
     * @return void
     */
    public function getUserByEmail(string $email){
        try{
            $existe = False;
            for($i=0;$i<count($this->users); $i++){
                if($this->users[$i]->getEmail_user() == $email){
                    $existe = true;
                    $index = $i;
                }
            }
            if($existe){
                return $this->users[$index];
            }else{
                require "views/404.php";
                throw new Exception("L'utilisateur demandé n'existe pas !");
            }
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    /**
     * method which add the user in the database
     *
     * @param string $email
     * @param string $password
     * @return void
     */
    public function ajoutUserBd(string $email, string $password){
        $req = "INSERT INTO user (email_user, pwd_user)
        values (:email_user, :pwd_user)";
        $statement = $this->model->getBdd()->prepare($req);
        $statement->bindValue(":email_user",$email,PDO::PARAM_STR); // Parametre permet un peu plus de securité
        $statement->bindValue(":pwd_user",$password,PDO::PARAM_STR);
        $resultat = $statement->execute();
        $statement->closeCursor();
        if($resultat > 0){
            $_SESSION['user']['email'] = $email;
            $_SESSION['user']['password'] = $password;
            $_SESSION['user']['id'] = $this->model->getBdd()->lastInsertId();

            $user = new UserEntity($this->model->getBdd()->lastInsertId(), $email, $password);
            $this->users[] = $user;
        }
        return $this->model->getBdd()->lastInsertId();
    }

    /**
     * method which edit/change the user in the database
     *
     * @param integer $id_user
     * @param string $pwd_user
     * @return void
     */
    public function modifUserBD(int $id_user, string $pwd_user){
        $req ="
        UPDATE user
        set pwd_user = :pwd_user
        where id_user = :id_user";
        $statement = $this->model->getBdd()->prepare($req);
        $statement->bindValue(":id_user",$id_user,PDO::PARAM_INT); // Parametre permet un peu plus de securité
        $statement->bindValue(":pwd_user",$pwd_user,PDO::PARAM_STR);
        $resultat = $statement->execute();
        $statement->closeCursor();

        if($resultat > 0){
            $_SESSION['user']['password'] = $pwd_user;
        }
    }

    /**
     * method which delete the user in the database
     *
     * @param integer $id
     * @return void
     */
    public function suppressionUserBd(int $id){ // SUPPR
        $req="
        DELETE from user where id_user = :id_user";
        $statement = $this->model->getBdd()->prepare($req);
        $statement->bindValue(":id_user",$id,PDO::PARAM_INT);
        $resultat = $statement->execute();
        $statement->closeCursor();

        if($resultat > 0){ // Si la req a aboutit
            session_unset();
        }
    }


    // getteurs

    /**
     * get the value of the users
     *
     * @return void
     */
    public function getUsers() : array // recupère le tableaux de musiques rempli
    { 
        return $this->users;
    }
}