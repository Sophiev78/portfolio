<?php

// En construction

class Compteur{

//attributs
private $fp;
private $nbr;

//construct
public function __construct(){
    $this->fp = fopen("compteur.txt", "r+"); // read and edit file
    $this->nbr=fgets($this->fp);
    $this->inc();
}   

public function __destruct(){
    fclose($this->fp);
}
//méthodes

public function inc(){ //implémente valeur compteur et l'ajoute dans compteur.txt
if(@$_SESSION["dejaVisitee"]!="oui"){ //@ -> échapper erreurs de notifs eventuelles au début
    $this->nbr++; //incrémente valeur nbr
    fseek($this->fp,0); //déplace curseur début du fichier
    fputs($this->fp,$this->nbr); // écrase ancienne valeur et remplacer par valeur nbr
    $_SESSION["dejaVisitee"]="oui";
    }

}

public function afficher(){ // va afficher les valeurs du compteur
    return $this->nbr;
}

}

//session_start(); //charge le compteur par session (pas à chaque actualisation de la page)
$cpt = new Compteur();
echo $cpt->afficher();

?>