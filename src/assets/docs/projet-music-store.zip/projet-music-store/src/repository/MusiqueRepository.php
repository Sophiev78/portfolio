<?php

require_once '../src/Model/Model.php';
require_once '../src/entity/MusiqueEntity.php';


class MusiqueRepository{ // héritage de class Model (connexion BDD)

    // attributs

    protected array $musiques;
    protected Model $model;

    /**
     * Undocumented function
     *
     * @param [type] $musique
     * @return void
     */    

    public function __construct(){
        $this->model = new Model();
    }

    //Méthodes

    public function chargementMusiques() // récupère les musiques de la bdd et va remplir le tableau $musiques
    {

            if(empty($_POST['categories']) && empty($_POST['artistes'])){
            $req = $this->model->getBdd()->prepare("SELECT * FROM musiques ORDER BY rand()");
            $req->execute();
            $mesMusiques = $req->fetchAll(PDO::FETCH_ASSOC);
            $req->closeCursor();

            foreach($mesMusiques as $musique){ 
                $this->musiques[]= new MusiqueEntity($musique['id_musique'],$musique['image'],$musique['titre'],$musique['description'],$musique['prix'], $musique["id_cat"]);
            }
        }
            if(isset($_POST['categories'])){
                foreach($_POST['categories'] as $categorie){
                    $req = $this->model->getBdd()->prepare("SELECT * FROM musiques JOIN categories ON musiques.id_cat = categories.id_cat WHERE categories.nom_cat = ?");
                    $req->execute([$categorie]);
                    $mesMusiques = $req->fetchAll(PDO::FETCH_ASSOC); //fetch_assoc évite les doublons du titre, de l'image dans la table musique de la bdd
                    $req->closeCursor();
                    foreach($mesMusiques as $musique){ 
                        $this->musiques[]= new MusiqueEntity($musique['id_musique'],$musique['image'],$musique['titre'],$musique['description'],$musique['prix'], $musique["id_cat"]);
                    } 
                }
            }  
            if(isset($_POST['artistes'])){
                foreach($_POST['artistes'] as $artiste){
                    $req = $this->model->getBdd()->prepare("SELECT * FROM musiques JOIN fait JOIN artistes ON musiques.id_musique = fait.id_musique && fait.id_artiste = artistes.id_artiste WHERE artistes.nom_artiste = ?");
                    $req->execute([$artiste]);
                    $mesMusiques = $req->fetchAll(PDO::FETCH_ASSOC); //fetch_assoc évite les doublons du titre, de l'image dans la table musique de la bdd
                    $req->closeCursor();
                    foreach($mesMusiques as $musique){ 
                        $this->musiques[]= new MusiqueEntity($musique['id_musique'],$musique['image'],$musique['titre'],$musique['description'],$musique['prix'], $musique["id_cat"]);
                    } 
                }
            } 
    }
    

    public function getMusiqueById(int $id): MusiqueEntity
    {
        try{
            $existe = false;
            for($i=0;$i<count($this->musiques); $i++){
                if($this->musiques[$i]->getId() == $id){
                    $index = $i;
                    $existe = true;
                }
            }
            if($existe){
                return $this->musiques[$index];
            }else{
                require "views/404.php";
                throw new Exception("La musique demandé n'existe pas !");
            }
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    public function ajoutMusiqueBd(string $image, string $titre, string $description, int $prix, int $id_cat){ // CREATE
        $req = "
        INSERT INTO musiques (image, titre, description, prix, id_cat)
        values(:image, :titre, :description, :prix, :id_cat)"; // bind values Permet de sécuriser les infos transmises par la requete
        $statement = $this->model->getBdd()->prepare($req);
        $statement->bindValue(":image",$image,PDO::PARAM_STR); // Parametre permet un peu plus de securité
        $statement->bindValue(":titre",$titre,PDO::PARAM_STR);
        $statement->bindValue(":description",$description,PDO::PARAM_STR);
        $statement->bindValue(":prix",$prix,PDO::PARAM_INT);
        $statement->bindValue(":id_cat",$id_cat,PDO::PARAM_INT);
        $resultat = $statement->execute();
        $statement->closeCursor();

        if($resultat > 0){ // Si la req a aboutit
            $musique = new MusiqueEntity($this->model->getBdd()->lastInsertId(), $image, $titre, $description, $prix, $id_cat);
            $this->musiques[] = $musique;
        }
    }

    public function suppressionMusiqueBd(int $id){ // SUPPR
        $req="
        DELETE from musiques where id_musique = :id_musique";
        $statement = $this->model->getBdd()->prepare($req);
        $statement->bindValue(":id_musique",$id,PDO::PARAM_INT);
        $resultat = $statement->execute();
        $statement->closeCursor();

        if($resultat > 0){ // Si la req a aboutit
            $musique = $this->getMusiqueById($id);
            unset($musique);
        }
    }

    public function modifMusiqueBd(int $id, string $image, string $titre, string $description, int $prix, int $id_cat){ // UPDATE
        $req ="
        UPDATE musiques
        set titre = :titre, description = :description, prix = :prix, image = :image, id_cat = :id_cat
        where id_musique = :id_musique";
        $statement = $this->model->getBdd()->prepare($req);
        $statement->bindValue(":id_musique",$id,PDO::PARAM_INT); // Parametre permet un peu plus de securité
        $statement->bindValue(":image",$image,PDO::PARAM_STR); 
        $statement->bindValue(":titre",$titre,PDO::PARAM_STR);
        $statement->bindValue(":description",$description,PDO::PARAM_STR);
        $statement->bindValue(":prix",$prix,PDO::PARAM_INT);
        $statement->bindValue(":id_cat",$id_cat,PDO::PARAM_INT);
        $resultat = $statement->execute();
        $statement->closeCursor();

        if($resultat > 0){
            $this->getMusiqueById($id)->setTitre($titre);
            $this->getMusiqueById($id)->setDescription($description);
            $this->getMusiqueById($id)->setPrix($prix);
            $this->getMusiqueById($id)->setImage($image);
            $this->getMusiqueById($id)->setId_cat($id_cat);
        }
    }

    // getteurs

    public function getMusiques() : array // recupère le tableaux de musiques rempli
    { 
        return $this->musiques;
    }

}