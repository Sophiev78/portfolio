<?php

// class Panier{
//     //Atrributs

//     // Methodes
//     public function creationPanier() : bool
//     {
//         if(!isset($_SESSION["panier"])){
//             $_SESSION["panier"] = array();
//             $_SESSION["panier"]["musique"] = array();
//             $_SESSION["panier"]["quantite"] = array();
//         }
//         return True;
//     }

//     public function ajouterArticle($musique, int $quantite){
//         if($this->creationPanier()){
//             for($i=0;$i<count($_SESSION["panier"]["musique"]);$i++){
//                 if($musique["titre"] == $_SESSION["panier"]["musique"][$i]["titre"]){
//                     $existe = True;
//                     $index = $i;
//                 }
//             }
//         }

//         if($existe != false){
//             $_SESSION["panier"]["quantite"][$index] += $quantite;
//         }else{
//             array_push($_SESSION["panier"]["musique"], $musique);
//             array_push($_SESSION["panier"]["quantite"], $quantite);
//         }
//     }

//     public function supprimerArticle($index){
//         if($this->creationPanier()){
//             $existe = true;
//         }

//         if($existe != False){
//             array_splice($_SESSION["panier"]["musique"], $index, 1);
//             array_splice($_SESSION["panier"]["quantite"], $index, 1);
//         }
//     }

//     public function montantPanier() : float
//     {
//         $total = 0;
//         for($i = 0; $i<count($_SESSION["panier"]["musique"]); $i++){
//             $total +=  $_SESSION["panier"]["musique"][$i]["prix"] * $_SESSION["panier"]["quantite"][$i];
//         }
//         return $total;
//     }

//     public function compterArticle() : int|bool
//     {

//         if(isset($_SESSION["panier"])){
//             $nbArticle = 0;
//             foreach($_SESSION["panier"]["quantite"] as $qte){
//                 $nbArticle += $qte;
//             }
//             return $nbArticle;
//         }else{
//             return False;
//         }
//     }

//     public function supprimerPanier(){
//         unset($_SESSION["panier"]);
//     }


//     public function afficherPanier(){
//         $musiques = $_SESSION["panier"]["musique"];
//         $html = "";
//         $index = 0;
//         if(count($musiques) == 0){
//             return 'Le panier est vide';
//         }else{
//             foreach($musiques as $musique){
//                 $prix = $musique["prix"];
//                 $titre = $musique["titre"];
//                 $image = $musique["image"];
//                 $quantite = $_SESSION["panier"]["quantite"][$index];
    
    
//                 $html .= <<<html
//                 <div class='card mt-5' style='width: 18rem;' data-id='$index'>
//                     <img src='../images/$image' class='card-img-top' alt='2pac'>
//                     <div class='card-body'>
//                         <h5 class='card-title'>$titre</h5>
//                         <span>Prix : $prix €</span><br>
//                         <span>Quantité : $quantite</span><br>
//                         <a href='panier.php?action=suppression&amp;index=$index' class='btn btn-secondary mt-2'>Supprimer du panier <i class='bi bi-trash'></i></a>
//                     </div>
//                 </div>
//                 html;
//                 $index++;
//             }
//             return $html;
//         }
//     }
// }