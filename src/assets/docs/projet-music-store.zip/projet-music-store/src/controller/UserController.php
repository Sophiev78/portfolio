<?php

require "../src/repository/UserRepository.php";

class UserController{

    // Attributs

    private UserRepository $userRepository;

    // Constructeur

    public function __construct()
    {
        $this->userRepository = new userRepository();
        $this->userRepository->chargementUsers();
    }

    public function afficherConnexion(){
        require 'views/connexion.php';
    }

    public function connexion(){

        $validationConnexion = false;
        $validationInscription = false;
        $validationAdmin = false;
        $id = null;

        if(isset($_POST) && !empty($_POST)){
            if(isset($_POST["email"]) && !empty($_POST["email"]) && isset($_POST["password"]) && !empty($_POST["password"])){
                $email = $_POST["email"];
                $password = $_POST["password"];
                if(isset($_POST["new"])){ // Inscription
                    foreach($this->userRepository->getUsers() as $user){
                        if($user->getEmail_user() == $email){ // Compte déjà existant
                            // throw new Exception("Ce compte existe déjà !");
                            header("Location:" . URL . "connexion");
                        }else{ // Création d'un nouveau compte + session
                           $validationInscription = true;
                        }
                    }
                }else{ // Connexion
                    foreach($this->userRepository->getUsers() as $user){
                        if($user->getEmail_user() == $email && $user->getPwd_user() == $password){ // Compte existant et bon
                            if($user->getId_user() == 1 || $user->getId_user() == 2 || $user->getId_user() == 3){ //Check si le compte est Admin
                                $validationConnexion = true;
                                $validationAdmin = true;
                                $id = $user->getId_user();
                            }else{
                                $validationConnexion = true;
                                $id = $user->getId_user();
                            }
                            $validationConnexion = true;
                        }else{ // Erreur mdp ou users
                            // throw new Exception("Erreur sur le Mdp ou le Nom de compte !");
                            header("Location:" . URL . "connexion");
                        }
                    }
                }
            }
        }

        return ["connexion" => $validationConnexion, "inscription" => $validationInscription, "admin" => $validationAdmin, "id" =>  $id];

    }

    public function connexionValidation(PanierController $panierController ,array $statement){
        $panierController->creationPanier();
        $connexion = $statement["connexion"];
        $inscription = $statement["inscription"];
        $admin = $statement["admin"];
        $id = $statement["id"];
        if($connexion && $admin){// Test sur la connexion
            $_SESSION["user"]["email"] = $_POST["email"];
            $_SESSION["user"]["password"] = $_POST["password"];
            $_SESSION["user"]["admin"] = true;
            $_SESSION["user"]["id"] = $id;
            header("Location:" . URL . "store");
        }else if($inscription){ // Test sur l'inscription
            $id = $this->userRepository->ajoutUserBd($_POST["email"], $_POST["password"]);
            $panierController->getPanierRepository()->ajoutPanierBd("", "", $id);
            header("Location:" . URL . "accueil");
        }else if($connexion){
            $_SESSION["user"]["email"] = $_POST["email"];
            $_SESSION["user"]["password"] = $_POST["password"];
            $_SESSION["user"]["admin"] = false;
            $_SESSION["user"]["id"] = $id;

            // Variables
            $musiques = $_SESSION["panier"]["musiques"];
            $quantites = $_SESSION["panier"]["quantites"];
            $index_quantite = 0;
            $existe = False;
            
            // MUSIQUES ET QUANTITE
           if(!empty($panierController->getPanierRepository()->getPanierbyUserId($id)->getMusiques())){
                $_SESSION["panier"]["musiques"] = $panierController->getPanierRepository()->getPanierbyUserId($id)->getMusiques();
                $_SESSION["panier"]["quantites"] = $panierController->getPanierRepository()->getPanierbyUserId($id)->getQuantites();
                foreach($musiques as $musique){
                    for($i=0;$i<count($_SESSION["panier"]["musiques"]);$i++){
                        if($musique->getTitre() == $_SESSION["panier"]["musiques"][$i]->getTitre()){
                            $existe = True;
                            $index = $i;
                        }
                    }
                    if($existe != false){
                        $_SESSION["panier"]["quantites"][$index] += $quantites[$index_quantite];
                        array_slice($quantites, $index_quantite, 0);
                    }else{
                        array_push($_SESSION["panier"]["musiques"], $musique);
                        array_push($_SESSION["panier"]["quantites"], 1);
                    }
                    $index_quantite++;
                }
                $panierController->getPanierRepository()->getPanierbyUserId($id)->setMusiques($_SESSION["panier"]["musiques"]);
                $panierController->getPanierRepository()->getPanierbyUserId($id)->setQuantites($_SESSION["panier"]["quantites"]);
           }

            // Id et Modif BD
            $panierId = $panierController->getPanierRepository()->getPanierbyUserId($id)->getId();
            $panierController->getPanierRepository()->modifPanierBD(serialize($_SESSION["panier"]["musiques"]), serialize($_SESSION["panier"]["quantites"]),$panierId);

            header("Location:" . URL . "accueil");
        }
    }

    public function modifCompte(){
        require 'views/compte.php';
    }

    public function  modifCompteValidation(){ // UPDATE
        $this->userRepository->modifUserBD($_POST['id'], $_POST['password']);
        header("Location:" . URL . "accueil");
    }

    public function suppressionUser(){ // SUPPRIME
        $this->userRepository->suppressionUserBd($_SESSION["user"]["id"]);
        header("Location:" . URL . "accueil");
    }

    // GETTER

    /**
     * Get the value of userRepository
     */ 
    public function getUserRepository()
    {
        return $this->userRepository;
    }
}