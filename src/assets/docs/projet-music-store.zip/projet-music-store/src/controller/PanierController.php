<?php

require_once "../src/repository/PanierRepository.php";

class PanierController{

    protected PanierRepository $panierRepository;

    public function __construct()
    {
        $this->panierRepository = new PanierRepository();
        $this->panierRepository->chargementPanier();
    }

    /**
     * Get the value of panierRepository
     */ 
    public function getPanierRepository()
    {
        return $this->panierRepository;
    }

    public function afficherPanier(){
        require "views/panier.php";
    }

    public function creationPanier(){
        if(!isset($_SESSION["panier"])){
            $_SESSION["panier"] = array();
            $_SESSION["panier"]["musiques"] = array();
            $_SESSION["panier"]["quantites"] = array();
            return True;
        }else{
            return true;
        }
    }

    public function ajoutMusiquePanier(MusiqueController $musiqueController, int $id, int $quantite){
        $musique = $musiqueController->getMusiqueRepository()->getMusiques()[$id-1];
        $existe = False;
        if($this->creationPanier()){
            for($i=0;$i<count($_SESSION["panier"]["musiques"]);$i++){
                if($musique->getTitre() == $_SESSION["panier"]["musiques"][$i]->getTitre()){
                    $existe = True;
                    $index = $i;
                }
            }
        }

        if($existe != false){
            $_SESSION["panier"]["quantites"][$index] += $quantite;
        }else{
            array_push($_SESSION["panier"]["musiques"], $musique);
            array_push($_SESSION["panier"]["quantites"], $quantite);
        }

        if(isset($_SESSION["user"])){
            $panierId = $this->panierRepository->getPanierbyUserId($_SESSION["user"]["id"])->getId();
            $this->panierRepository->modifPanierBD(serialize($_SESSION["panier"]["musiques"]), serialize($_SESSION["panier"]["quantites"]),$panierId);
        }

        header("Location:" . URL . "store");
    }

    public function supprimerArticle(int $index){
        $existe = False;
        if($this->creationPanier()){
            $existe = true;
        }
        if($existe != False){
            array_splice($_SESSION["panier"]["musiques"], $index, 1);
            array_splice($_SESSION["panier"]["quantites"], $index, 1);
            if(isset($_SESSION["user"])){
                $panierId = $this->panierRepository->getPanierbyUserId($_SESSION["user"]["id"])->getId();
                $this->panierRepository->modifPanierBD(serialize($_SESSION["panier"]["musiques"]), serialize($_SESSION["panier"]["quantites"]),$panierId);
            }
        }
        header("Location:" . URL . "panier");
    }
}

?>