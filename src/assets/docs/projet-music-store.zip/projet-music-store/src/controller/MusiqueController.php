<?php

require "../src/repository/MusiqueRepository.php";

class MusiqueController{

    // Attributs

    public MusiqueRepository $musiqueRepository;

    // Constructeur

    public function __construct()
    {
        $this->musiqueRepository = new MusiqueRepository();
        $this->musiqueRepository->chargementMusiques();
    }

    public function afficherMusiques($artisteController, $categorieController){
        $artistes = $artisteController->afficherArtistes();
        $categories = $categorieController->afficherCategories();
        $musiques = $this->musiqueRepository->getMusiques();
        require "views/store.php";
    }

    public function afficherFicheMusique(int $id){
        $musique = $this->musiqueRepository->getMusiqueById($id);
        require "views/musique/ficheMusique.php";
    }

    public function ajoutMusique(){
        require "views/musique/ajoutMusique.php";
    }

    public function ajoutMusiqueValidation(){ // CREATE
        // $_POST['image'] = "2pac.jpg";
        // $_POST['titre'] = "Test1";
        // $_POST['description'] = "Des1";
        // $_POST['prix'] = 2;
        // $_POST['id_cat'] = 1;
        // $_POST['id_artiste'] = 1;
        $this->musiqueRepository->ajoutMusiqueBD($_POST['image'], $_POST['titre'], $_POST['description'], $_POST['prix'], $_POST['id_cat']);
        header("Location:" . URL . "store");
    }

    public function suppressionMusique(int $id){ // SUPPRIME
        $this->musiqueRepository->suppressionMusiqueBd($id);
        header("Location:" . URL . "store");
    }

    public function modifMusique(int $id){
        $musique = $this->musiqueRepository->getMusiqueById($id);
        require "views/musique/modifMusique.php";
    }

    public function  modifMusiqueValidation(){ // UPDATE
        $this->musiqueRepository->modifMusiqueBD($_POST['id'], $_POST['image'], $_POST['titre'], $_POST['description'], $_POST['prix'], $_POST['id_cat']);
        header("Location:" . URL . "store");
    }

    /**
     * Get the value of musiqueRepository
     */ 
    public function getMusiqueRepository()
    {
        return $this->musiqueRepository;
    }
}














// class MusiqueController{

// //creat
// public function creat(MusiqueEntity $musiqueEntity): PDOStatement{
//     $pdoStatement = $this->EntityManager->prepare("creat Musique set id = :id, image = :image, titre = :titre, description = :description, prix = :prix where id= :id");
//     $pdoStatement->execute([
//         "id" => $musiqueEntity->getId(),
//         "image" => $musiqueEntity->getImage(),
//         "titre" => $musiqueEntity->getTitre(),
//         "description" => $musiqueEntity->getDescription(),
//         "prix" => $musiqueEntity->getPrix()
//     ]);
//     return $pdoStatement;


// //read
// public function read(MusiqueEntity $musiqueEntity): PDOStatement{
//     $pdoStatement = $this->EntityManager->prepare("read Musique set id = :id, image = :image, titre = :titre, description = :description, prix = :prix where id= :id");
//     $pdoStatement->execute([
//         "id" => $musiqueEntity->getId(),
//         "image" => $musiqueEntity->getImage(),
//         "titre" => $musiqueEntity->getTitre(),
//         "description" => $musiqueEntity->getDescription(),
//         "prix" => $musiqueEntity->getPrix()
//     ]);
//     return $pdoStatement;

// //update
// public function update(MusiqueEntity $musiqueEntity): PDOStatement{
//     $pdoStatement = $this->EntityManager->prepare("update Musique set id = :id, image = :image, titre = :titre, description = :description, prix = :prix where id= :id");
//     $pdoStatement->execute([
//         "id" => $musiqueEntity->setId(),
//         "image" => $musiqueEntity->setImage(),
//         "titre" => $musiqueEntity->setTitre(),
//         "description" => $musiqueEntity->setDescription(),
//         "prix" => $musiqueEntity->setPrix()
//     return $pdoStatement;

// //delete
// public function delete(MusiqueEntity $musiqueEntity): PDOStatement{
//     $pdoStatement = $this->EntityManager->prepare("delete Musique set id = :id, image = :image, titre = :titre, description = :description, prix = :prix where id= :id");
//     $pdoStatement->execute([
//         "id" => $musiqueEntity->setId(),
//         "image" => $musiqueEntity->setImage(),
//         "titre" => $musiqueEntity->setTitre(),
//         "description" => $musiqueEntity->setDescription(),
//         "prix" => $musiqueEntity->setPrix()
//     return $pdoStatement;


// }   