<?php

require "../src/repository/ArtisteRepository.php";

class ArtisteController{

    protected ArtisteRepository $artisteRepository;

    /**
     * use the "artist repository" class to manage the crud in the admin part
     * and to display the artists in the dropdown menu in the "store" view
     */
    public function __construct()
    {
        $this->artisteRepository = new ArtisteRepository();
        $this->artisteRepository->chargementArtistes();
    }

    public function afficherArtistes()
    {
        return $this->artisteRepository->getArtistes();
    }

    //Admin
    
    public function ajoutArtiste(){
        require "views/artiste/ajoutArtiste.php";
    }

    public function ajoutArtisteValidation(){ // CREATE
        $this->artisteRepository->ajoutArtisteBD($_POST['nom_artiste']);
        header("Location:" . URL . "store");
    }

    public function suppressionArtiste(int $id){ // SUPPRIME
        $this->artisteRepository->suppressionArtisteBd($id);
        header("Location:" . URL . "store");
    }

    public function modifArtiste(int $id){
        $artiste = $this->artisteRepository->getArtisteById($id);
        require "views/artiste/modifArtiste.php";
    }

    public function  modifArtisteValidation(){ // UPDATE
        $this->artisteRepository->modifArtisteBD($_POST['id_artiste'],$_POST['nom_artiste']);
        header("Location:" . URL . "store");
    }
}




























// class ArtisteController{

    
//     //creat
//     public function creat(ArtisteEntity $artisteEntity): PDOStatement{
//         $pdoStatement = $this->EntityManager->prepare("creat Artiste set id_artiste = :id_artiste, nom_artiste = :nom_artiste where id= :id");
//         $pdoStatement->execute([
//             "id_artiste" => $categorieEntity->getId(),
//             "nom_artiste" => $categorieEntity->getNomArt()
//     ]);
//     return $pdoStatement;
    
    
//     //read
//     public function read(CategorieEntity $categorieEntity): PDOStatement{
//         $pdoStatement = $this->EntityManager->prepare("read Artiste set id_artiste = :id_artiste, nom_artiste = :nom_artiste where id= :id");
//         $pdoStatement->execute([
//             "id_artiste" => $categorieEntity->getId(),
//             "nom_artiste" => $categorieEntity->getNomArt()
//     ]);
//     return $pdoStatement;
    
//     //update
//     public function update(CategorieEntity $categorieEntity): PDOStatement{
//         $pdoStatement = $this->EntityManager->prepare("update Artiste set id_artiste = :id_artiste, nom_artiste = :nom_artiste where id= :id");
//         $pdoStatement->execute([
//             "id_artiste" => $categorieEntity->getId(),
//             "nom_artiste" => $categorieEntity->getNomArt()
//         ]);
//         return $pdoStatement;

//         //delete
//         public function delete(CategorieEntity $categorieEntity): PDOStatement{
//     $pdoStatement = $this->EntityManager->prepare("delete Artiste set id_artiste = :id_artiste, nom_artiste = :nom_artiste where id= :id");
//     $pdoStatement->execute([
//         "id_artiste" => $categorieEntity->getId(),
//         "nom_artiste" => $categorieEntity->getNomArt()
//     ]);
//     return $pdoStatement;
// }

