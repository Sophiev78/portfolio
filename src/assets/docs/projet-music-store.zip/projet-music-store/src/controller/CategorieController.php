<?php

require "../src/repository/CategorieRepository.php";

class CategorieController{

    protected CategorieRepository $categorieRepository;

    public function __construct()
    {
        $this->categorieRepository = new CategorieRepository();
        $this->categorieRepository->chargementCategories();
    }

    public function afficherCategories()
    {
        return $this->categorieRepository->getCategories();
    }

    //Admin
    
    public function ajoutCategorie(){
        require "views/categorie/ajoutCategorie.php";
    }

    public function ajoutCategorieValidation(){ // CREATE
        $this->categorieRepository->ajoutCategorieBD($_POST['nom_cat']);
        header("Location:" . URL . "store");
    }

    public function suppressionCategorie(int $id){ // SUPPRIME
        $this->categorieRepository->suppressionCategorieBd($id);
        header("Location:" . URL . "store");
    }

    public function modifCategorie(int $id){
        $categorie = $this->categorieRepository->getCategorieById($id);
        require "views/categorie/modifCategorie.php";
    }

    public function  modifCategorieValidation(){ // UPDATE
        $this->categorieRepository->modifCategorieBD($_POST['id_cat'],$_POST['nom_cat']);
        header("Location:" . URL . "store");
    }
}




















// class CategorieController{
// //creat
// public function creat(CategorieEntity $categorieEntity): PDOStatement{
//     $pdoStatement = $this->EntityManager->prepare("creat Categorie set id = :id, nom_cat = :nom_cat where id= :id");
//     $pdoStatement->execute([
//         "id_cat" => $categorieEntity->getId(),
//         "nom_cat" => $categorieEntity->getNomCat()
//     ]);
//     return $pdoStatement;


// //read
// public function read(CategorieEntity $categorieEntity): PDOStatement{
//     $pdoStatement = $this->EntityManager->prepare("read Categorie set id = :id, nom_cat = :nom_cat where id= :id");
//     $pdoStatement->execute([
//         "id_cat" => $categorieEntity->getId(),
//         "nom_cat" => $categorieEntity->getNomCat()
//     ]);
//     return $pdoStatement;

// //update
// public function update(CategorieEntity $categorieEntity): PDOStatement{
//     $pdoStatement = $this->EntityManager->prepare("update Categorie set id = :id, nom_cat = :nom_cat where id= :id");
//     $pdoStatement->execute([
       
//         "id_cat" => $categorieEntity->setId(),
//         "nom_cat" => $categorieEntity->setNomCat()
//         ]);
//         return $pdoStatement;

// //delete
// public function delete(CategorieEntity $categorieEntity): PDOStatement{
//     $pdoStatement = $this->EntityManager->prepare("delete Categorie set id = :id, nom_cat = :nom_cat where id= :id");
//     $pdoStatement->execute([
//         "id_cat" => $categorieEntity->setId(),
//         "nom_cat" => $categorieEntity->setNomCat()
//         ]);
//         return $pdoStatement;


// }