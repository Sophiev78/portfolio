<?php

class ArtisteEntity{

    //  Attributs

    protected int $id_artiste;
    protected string $nom_artiste;
    
        /**
         * class which takes the artists table from the DB
         *
         * @param integer $id_artiste
         * @param string $nom_artiste
         */

         
    // constructeur

    public function __construct(int $id_artiste = null, string $nom_artiste)
    {
        $this-> id_artiste = $id_artiste;
        $this->nom_artiste = $nom_artiste;
    }

    // getteurs setteurs

        /**
         * Get the value of id
         *
         * @return integer
         */

    public function getIdArtiste() : int
    {
        return $this->id_artiste;
    }
    

    /**
     * Set the value of id
     *
     * @param integer $id_artiste
     * @return void
     */
    public function setId(int $id_artiste)
    {
         $this->id_artiste = $id_artiste;
         return $this;
    }
    
    
    /**
     * get the value of nomArt
     *
     * @return string
     */
    public function getNomArt() : string
    {
        return $this->nom_artiste;
    }

    /**
     * set the value of nomArt
     *
     * @param string $nom_artiste
     * @return void
     */
    public function setNomArt(string $nom_artiste)
    {
         $this->nom_artiste= $nom_artiste;
         return $this;
    }
    
}