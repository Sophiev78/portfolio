<?php

    class CategorieEntity{

        //attributs

        protected int $id_cat;
        protected string $nom_cat;

        // constructeur

        
    /**
     * class which takes the categories table from the DB
    *
    * @param integer $id_cat
    * @param string $nom_cat
    */     
       
        public function __construct(int $id_cat, string $nom_cat)
        {
            $this->id_cat = $id_cat;
            $this->nom_cat = $nom_cat;
        }

        // getteurs setteurs
        
        /**
         * get the value of id
         *
         * @return integer
         */
        public function getIdCat() : int
        {
            return $this->id_cat;
        }

        /**
         * set the value of id
         *
         * @param integer $id_cat
         * @return void
         */        
        public function setId(int $id_cat)
        {
            $this->id_cat = $id_cat;
                return $this;
        }

        /**
         * get the value of id NomCat
         *
         * @return string
         */
        public function getNomCat() : string
        {
            return $this->nom_cat;
        }

        /**
         * set the value of NomCat
         *
         * @param string $nom_cat
         * @return void
         */
        public function setNomCat(string $nom_cat)
        {
            $this->nom_cat= $nom_cat;
                return $this;
        }



}