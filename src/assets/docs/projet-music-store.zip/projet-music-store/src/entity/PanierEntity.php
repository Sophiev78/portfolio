<?php

class PanierEntity{
    // Attributs
    protected int $id;
    protected string $musiques;
    protected string $quantites;
    protected int $id_user;


/**
 * class which takes the basket table from the DB
 *
 * @param integer $id
 * @param string $musiques
 * @param string $quantites
 * @param integer $id_user
 */
    public function __construct(int $id, string $musiques, string $quantites, int $id_user)
    {
        $this->id = $id;
        $this->musiques = $musiques;
        $this->quantites = $quantites;
        $this->id_user = $id_user;
    }

    /**
     * Get the value of id
     */ 
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of musiques
     */ 
    public function getMusiques()
    {
        return unserialize($this->musiques);
    }

    /**
     * Set the value of musiques
     *
     * @return  self
     */ 
    public function setMusiques(array $musiques)
    {
        $musiques = serialize($musiques);
        $this->musiques = $musiques;
        return $this;
    }

    /**
     * Get the value of quantites
     */ 
    public function getQuantites()
    {
        return unserialize($this->quantites);
    }

    /**
     * Set the value of quantites
     *
     * @return  self
     */ 
    public function setQuantites(array $quantites)
    {
        $quantites = serialize($quantites);
        $this->quantites = $quantites;

        return $this;
    }

    /**
     * Get the value of id_user
     */ 
    public function getId_user()
    {
        return $this->id_user;
    }

    /**
     * Set the value of id_user
     *
     * @return  self
     */ 
    public function setId_user($id_user)
    {
        $this->id_user = $id_user;

        return $this;
    }
}

?>