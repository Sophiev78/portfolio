<?php

    class MusiqueEntity{

        // Attributs
    
        protected int $id;
        protected string $image;
        protected string $titre;
        protected string $description;
        protected int $prix;
        protected int $id_cat;
        protected int $id_artiste;
        
        // constructeur

        /**
         * class which takes the music table from the DB
         *
         * @param integer $id
         * @param string $image
         * @param string $titre
         * @param string $description
         * @param integer $prix
         */
        public function __construct(int $id, string $image, string $titre, string $description,int $prix, int $id_cat)
        {
            $this->id = $id;
            $this->image= $image;
            $this->titre= $titre;
            $this->description= $description;
            $this->prix= $prix;
            $this->id_cat = $id_cat;
        }
        
    
        /**
         * get the value of the id
         *
         * @return integer
         */
        public function getId() : int
        {
            return $this->id;
        }

        /**
         * set the value of the id
         *
         * @param integer $id
         * @return void
         */
        public function setId(int $id)
        {
            $this->id=$id;
            return $this;
        }
        
        /**
         * get the value of the image
         *
         * @return string
         */
        public function getImage() : string 
        {
            return $this->image;
        }

        /**
         * set the value of the image
         *
         * @param string $image
         * @return void
         */
        public function setImage(string $image)
        {
            $this->image=$image;
            return $this;
        }

        /**
         * get the value of the title
         *
         * @return string
         */
        public function getTitre() :string
        {
            return $this->titre;
        }

        /**
         * set the value of the title
         *
         * @param string $title
         * @return void
         */
        public function setTitre( string $title)
        {
            $this->titre=$title;
            return $this;
        }

        /**
         * get value of the description
         *
         * @return string
         */
        public function getDescription() : string
        {
            return $this->description;
        }

        /**
         * set value of the description
         *
         * @param string $description
         * @return void
         */
        public function setDescription( string $description)
        {
            $this->description=$description;
            return $this;
        }
        
        /**
         * get the value of the price
         *
         * @return integer
         */
        public function getPrix() : int
        {
            return $this->prix;
        }

        /**
         * set the value of the price
         *
         * @param string $prix
         * @return void
         */
        public function setPrix(string $prix)
        {
            $this->prix=$prix;
            return $this;
        } 
        
        /**
         * Get the value of id_cat
         */ 
        public function getId_cat()
        {
            return $this->id_cat;
        }

        /**
         * Set the value of id_cat
         *
         * @return  self
         */ 
        public function setId_cat($id_cat)
        {
            $this->id_cat = $id_cat;
            return $this;
        }
    }

