<?php

class Model{

    // attribut

    protected $pdo; // accessible par toutes les classes qui vont hériter de celle-ci comme musiquemanager par exemple
    protected $dns = "mysql:host=localhost;dbname=store4;charset=utf8";
    protected $user = "root";
    protected $pwd = "";

    /**
     * connection to the database "store4"
     */
    public function __construct()
    {
        try{
            $this->pdo = new PDO($this->dns, $this->user, $this->pwd); 
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_WARNING);
        }catch(PDOException $pdoException){
            echo "Le probleme est : " . $pdoException . " ! ";
        }

    }

    /**
     * get the value of the bdd
     *
     * @return void
     */
    public function getBdd()
    {
        return $this->pdo;
    }
}

