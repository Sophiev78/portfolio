<?php

class Compteur{

    //attributs
    private $fileOpen;
    private $number;
    
    //construct

    /**
     * class which open the file (compteur.txt) 
     */

    public function __construct(){
        $this->fileOpen = fopen("../src/compteur/compteur.txt", "r+"); // read and edit file
        $this->number = fgets($this->fileOpen);
        $this->increment();
    }   


    /**
     * add one in the file named "compteur.txt" to each view visite
     *
     * @return void
     */
    public function increment(){ //
    if(@$_SESSION["dejaVisitee"]!="oui"){ //@ -> échapper erreurs de notifs eventuelles au début
        $this->number++; //incrémente valeur nbr
        fseek($this->fileOpen,0); //déplace curseur début du fichier
        fputs($this->fileOpen,$this->number); // écrase ancienne valeur et remplacer par valeur nbr
        $_SESSION["dejaVisitee"]="oui";
        }
    }

    /**
     * show the number of visits on the home page
     *
     * @return void
     */

    public function afficher(){ 
    return $this->number;
    }

}

$compteur = new Compteur();




?>
