<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

</head>
<body>

<?php

if(isset($_GET['page'])){
  $page = $_GET['page'];
}else{
  $page = "";
}

?>
        

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">

    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link <?php if($page === "" || $page === 'accueil') : ?> active <?php endif;?>" href="<?= URL ?>accueil">Accueil
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if($page === "store") : ?> active <?php endif;?>" href="<?= URL ?>store">Store</a>
        </li>
      </ul>
      <ul class="d-flex navbar-nav">
      <?php if(isset($_SESSION["user"])) : ?>
        <li class="nav-item">
            <a class="nav-link <?php if($page === "compte") : ?> active <?php endif;?>" href="<?= URL ?>compte"><i class="bi bi-person-circle"></i></a>
        </li>
      <?php endif; ?>
      <?php if((isset($_SESSION["user"]) && $_SESSION["user"]["admin"] == false) || !isset($_SESSION["user"])) : ?>
        <li class="nav-item">
            <a class="nav-link <?php if($page === "panier") : ?> active <?php endif;?>" href="<?= URL ?>panier"><i class="bi bi-cart2"></i></a>
        </li>
      <?php endif; ?>
        <?php if(isset($_SESSION["user"])) : ?>
        <li class="nav-item">
            <a class="nav-link <?php if($page === "deconnexion") : ?> active <?php endif;?>" href="<?= URL ?>deconnexion">Déconnexion</a>
        </li>
        <?php endif; ?>
        <?php if(!isset($_SESSION["user"])) : ?>
        <li class="nav-item">
            <a class="nav-link <?php if($page === "connexion") : ?> active <?php endif;?>" href="<?= URL ?>connexion">Connexion</a>
        </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<style>
      .dashboard{
        color:#fff;
      }
      .background{
        background: rgb(202,97,228);
        background: linear-gradient(90deg, rgba(202,97,228,1) 16%, rgba(29,253,213,1) 92%);
      }
</style>

<div class="container-fluid background">
    <h1 class="text-center mb-5"><?= $titre?></h1>
    <?=$content?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>