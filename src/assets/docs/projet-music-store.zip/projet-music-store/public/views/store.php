<?php

ob_start();

?>

<div class="container">
    <form action="" method="post">
        <div class="row">
            <div class="col">
                <select class="form-select btn-dark"name="categories[]">
                    <option>--Choisir par catégories--</option>
                    <?php
                    foreach( $categories as  $categorie) :
                    ?>
                    <option value="<?= $categorie->getNomCat()?>"><?= $categorie->getNomCat()?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-secondary">choisir</button>
            </div>
            
            <div class="col">
                <select class="form-select btn-dark" name="artistes[]">
                    <option>--Choisir par artistes--</option>
                    <?php
                    foreach($artistes as $artiste) :
                    ?>
                    <option value="<?= $artiste->getNomArt()?>"><?= $artiste->getNomArt()?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-secondary">choisir</button>
            </div>
        </div>
    </form>
</div>

<div class="container musiques">
    <div class="row text-center mx-auto justify-content-evenly">
        <?php
            foreach($musiques as $musique) :
        ?>
        <div class="card mt-5" style="width: 18rem;">
        <img src="<?=URL?>images/<?=$musique->getImage()?>" class="card-img-top" alt="image-album">
            <div class="card-body">

                <!-- INFO Musique -->
                <h5 class="card-title"><a href="<?= URL ?>store/m/<?=$musique->getId();?>"><?=$musique->getTitre()?></a></h5>
                <p><?=$musique->getDescription()?></p>
                <span>Prix : <?=$musique->getPrix()?>€</span><br>

                <!-- PANIER -->
                <?php if((isset($_SESSION["user"]) && $_SESSION["user"]["admin"] == false) || !isset($_SESSION["user"])) : ?>
                    <form method="POST" action="<?=URL?>store/ap/<?=$musique->getId();?>">
                        <button type="submit" class="btn btn-success mt-2">Ajouter au panier <i class="bi bi-cart-plus"></i></button>
                    </form>
                <?php endif; ?>

                <!-- CRUD -->
                <?php if(isset($_SESSION["user"]) && $_SESSION["user"]["admin"] == true) : ?>
                    <a href="<?=URL?>store/mm/<?=$musique->getId();?>" class="btn btn-warning mt-2">Modifier<i class="bi bi-arrow-repeat"></i></a>
                    <form method="POST" action="<?=URL?>store/s/<?=$musique->getId();?>" onsubmit="return confirm('Voulez vous vraiment supprimer cette musique ?')">
                        <button class="btn btn-danger mt-2" type="submit">Supprimer <i class="bi bi-trash-fill"></i></button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php  if(isset($_SESSION["user"]) && $_SESSION["user"]["admin"] == true) : ?>
    <div class="container">
        <a href="<?=URL?>store/a" class="btn btn-success d-block mt-2">Ajouter une musique</a><br>

        <a href="<?=URL?>store/ac" class="btn btn-success d-block mt-2 mb-3">Ajouter une catégorie</a>
        <a href="<?=URL?>store/cm/<?=$categorie->getIdCat();?>" class="btn btn-warning d-block mt-3 mb-3">Modifier une catégorie<i class="bi bi-arrow-repeat"></i></a>
        <div class="row text-center">
            <form method="POST" action="<?=URL?>store/sc/<?=$categorie->getIdCat();?>" onsubmit="return confirm('Voulez vous vraiment supprimer cette catégorie ?')">
                <button class="btn btn-danger" type="submit">Supprimer <i class="bi bi-trash-fill"></i></button>
            </form>
        </div>
        <a href="<?=URL?>store/aa" class="btn btn-success d-block mt-3 mb-3">Ajouter un artiste</a>
        <a href="<?=URL?>store/ma/<?=$artiste->getIdArtiste();?>" class="btn btn-warning d-block mt-3 mb-3">Modifier un artiste</a>
        <div class="row text-center">
            <form method="POST" action="<?=URL?>store/sa/<?=$artiste->getIdArtiste();?>" onsubmit="return confirm('Voulez vous vraiment supprimer cet artiste ?')">
                <button class="btn btn-danger" type="submit">Supprimer <i class="bi bi-trash-fill"></i></button>
            </form>
        </div>
<?php endif; ?>

<?php
$content = ob_get_clean();
$titre = "Bienvenue sur Music Store";
$title = "Store";
require "commun/template.php";

?>


