<?php

ob_start();
?>

<div class="container">
    <form method="POST" action="<?=URL?>store/sav">
    <div class="mb-3">
        <div class="form-group">
            <label for="nom_artiste" class="form-label">Nom de l'artiste</label>
            <input type="text" class="form-control" id="nom_artiste" name="nom_artiste">
        </div>
        <button type="submit" class="btn btn-primary">Valider</button>
    </form>
</div>

<?php

$content = ob_get_clean();
$titre = "Ajoute l'artiste";
$title = "Ajout";
require "commun/template.php";