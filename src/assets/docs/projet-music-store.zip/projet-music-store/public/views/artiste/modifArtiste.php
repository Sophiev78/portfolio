<?php

ob_start();

?>

Ici la page de modification de <?= $artiste->getNomArt();?>

<div class="container">
    <form method="POST" action="<?=URL?>store/mav">
    <div class="mb-3">
        <div class="form-group">
            <label for="nom_artiste" class="form-label">Artiste</label>
            <input type="text" class="form-control" id="nom_artiste" name="nom_artiste" value="<?=$artiste->getNomArt();?>">
        </div>
        <input type="hidden" name="id_artiste" value="<?=$artiste->getIdArtiste();?>">
        <button type="submit" class="btn btn-primary">Valider</button>
    </form>
</div>

<?php

$content = ob_get_clean();
$titre = "Modification information";
$title = "Modification";
require "commun/template.php";