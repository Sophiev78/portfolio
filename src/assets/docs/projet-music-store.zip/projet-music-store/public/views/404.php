<?php

ob_start();
?>

<h1>Erreur 404</h1>
<p>Tout les chemins mènent à FVB Store, sauf celui ci !</p>

<?php

$content = ob_get_clean();
$titre = "Erreur 404";
$title = "Erreur 404";
require "commun/template.php";