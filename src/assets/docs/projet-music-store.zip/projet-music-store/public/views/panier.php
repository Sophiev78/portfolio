<?php
ob_start();
?>

<div class="container d-flex flex-row">


<?php

if(isset($_SESSION["panier"]["musiques"])) :
    $musiques = $_SESSION["panier"]["musiques"];
    $quantites = $_SESSION["panier"]["quantites"];
    for($i=0; $i<count($musiques); $i++) : 
?>

            <div class="card mt-5" style="width: 18rem;">
                <img src="<?=URL?>images/<?=$musiques[$i]->getImage()?>" class="card-img-top" alt="image-album">
                <div class="card-body">

                    <!-- INFO Musique -->
                    <h5 class="card-title"><a href="<?= URL ?>store/m/<?=$musiques[$i]->getId();?>"><?=$musiques[$i]->getTitre()?></a></h5>
                    <p><?=$musiques[$i]->getDescription()?></p>
                    <span>Prix : <?=$musiques[$i]->getPrix()?>€</span><br>
                    <span>Quantite : <?=$quantites[$i]?></span><br>
                    <form method="POST" action="<?=URL?>panier/s/<?=$i?>" onsubmit="return confirm('Voulez vous vraiment supprimer cette musique de votre panier?')">
                        <button class="btn btn-danger mt-2" type="submit">Supprimer du panier<i class="bi bi-trash-fill"></i></button>
                    </form>
                </div>
            </div>
<?php 
    endfor;
    else :
?>
    <p>Votre Panier est vide! :(</p>


<?php 
endif;
?>

</div>
<?php
$content = ob_get_clean();
$titre = "Panier";
$title = "Panier";
require "commun/template.php";
?>