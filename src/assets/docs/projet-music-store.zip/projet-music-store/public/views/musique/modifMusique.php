<?php

ob_start();

?>

Ici la page de modification de <?= $musique->getTitre();?>

<div class="container">
    <form method="POST" action="<?=URL?>store/mmv">
    <div class="mb-3">
        <div class="form-group">
            <label for="titre" class="form-label">Titre</label>
            <input type="text" class="form-control" id="titre" name="titre" value="<?=$musique->getTitre();?>">
        </div>
        <div class="form-group">
            <label for="description" class="form-label">Description</label>
            <input type="text" class="form-control" id="description" name="description" value="<?=$musique->getDescription();?>">
        </div>
        <div class="form-group">
            <label for="prix" class="form-label">Prix</label>
            <input type="number" class="form-control" id="prix" name="prix" value="<?=$musique->getPrix();?>">
        </div>
        <div class="form-group">
            <label for="image" class="form-label">Image</label>
            <input type="text" class="form-control" id="image" name="image" value="<?=$musique->getImage();?>">
        </div>
        <div class="form-group">
            <label for="id_cat" class="form-label">ID Categorie</label>
            <input type="number" class="form-control" id="id_cat" name="id_cat" value="<?=$musique->getId_cat();?>">
        </div>
        <input type="hidden" name="id" value="<?=$musique->getId();?>">
        <button type="submit" class="btn btn-primary">Valider</button>
    </form>
</div>

<?php

$content = ob_get_clean();
$titre = "Modification information";
$title = "Modification";
require "commun/template.php";