<?php

ob_start();
?>

<div class="container">
    <form method="POST" action="<?=URL?>store/av">
    <div class="mb-3">
        <div class="form-group">
            <label for="titre" class="form-label">Titre</label>
            <input type="text" class="form-control" id="titre" name="titre">
        </div>
        <div class="form-group">
            <label for="description" class="form-label">Description</label>
            <input type="text" class="form-control" id="description" name="description">
        </div>
        <div class="form-group">
            <label for="prix" class="form-label">Prix</label>
            <input type="number" class="form-control" id="prix" name="prix">
        </div>
        <div class="form-group">
            <label for="image" class="form-label">Image</label>
            <input type="text" class="form-control" id="image" name="image">
        </div>
        <div class="form-group">
            <label for="id_cat" class="form-label">ID Categorie</label>
            <input type="text" class="form-control" id="id_cat" name="id_cat">
        </div>
        <button type="submit" class="btn btn-primary">Valider</button>
    </form>
</div>

<?php

$content = ob_get_clean();
$titre = "Ajoute ta musique";
$title = "Ajout";
require "commun/template.php";