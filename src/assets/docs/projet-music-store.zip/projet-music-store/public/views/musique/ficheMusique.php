<?php

ob_start();
?>

Ici la fiche Musique de <?= $musique->getTitre();?>

<div class="row">
    <div class="col-md-6">
        <img src="<?=URL?>images/<?=$musique->getImage();?>">
    </div>
    <div class="col-md-6">
        <h5><?=$musique->getDescription();?></h5>
        <p><?=$musique->getPrix();?></p>
    </div>
</div>

<?php

$content = ob_get_clean();
$titre = "Fiche technique de " . $musique->getTitre();
$title = $musique->getTitre();
require "commun/template.php";