<?php

ob_start();

?>

Ici la page de modification de <?= $categorie->getNomCat();?>

<div class="container">
    <form method="POST" action="<?=URL?>store/cmv">
    <div class="mb-3">
        <div class="form-group">
            <label for="nom_cat" class="form-label">Catégorie</label>
            <input type="text" class="form-control" id="nom_cat" name="nom_cat" value="<?=$categorie->getNomCat();?>">
        </div>
        <input type="hidden" name="id_cat" value="<?=$categorie->getIdCat();?>">
        <button type="submit" class="btn btn-primary">Valider</button>
    </form>
</div>

<?php

$content = ob_get_clean();
$titre = "Modification information";
$title = "Modification";
require "commun/template.php";