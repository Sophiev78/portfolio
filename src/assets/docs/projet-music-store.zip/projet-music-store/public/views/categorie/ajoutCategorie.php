<?php

ob_start();
?>

<div class="container">
    <form method="POST" action="<?=URL?>store/acv">
    <div class="mb-3">
        <div class="form-group">
            <label for="nom_cat" class="form-label">Nom de la Categorie</label>
            <input type="text" class="form-control" id="nom_cat" name="nom_cat">
        </div>
        <button type="submit" class="btn btn-primary">Valider</button>
    </form>
</div>

<?php

$content = ob_get_clean();
$titre = "Ajoute ta catégorie";
$title = "Ajout";
require "commun/template.php";