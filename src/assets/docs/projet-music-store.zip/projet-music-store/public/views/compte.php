<?php

ob_start();


?>

<div class="container">
    <form method="POST" action="<?=URL?>compte/mv">
    <div class="mb-3">
        <div class="form-group">
            <label for="password" class="form-label">Changer de mot de passe</label>
            <input type="text" class="form-control" id="password" name="password" value="<?=$_SESSION["user"]["password"]?>">
        </div>
        <input type="hidden" name="id" value="<?=$_SESSION["user"]["id"]?>">
        <button type="submit" class="btn btn-primary">Valider</button>
    </form>
    <?php if(isset($_SESSION["user"]) && $_SESSION["user"]["admin"] == false) : ?>
        <form method="POST" action="<?=URL?>compte/s" onsubmit="return confirm('Voulez vous vraiment supprimer votre compte ?')">
            <button class="btn btn-danger mt-2" type="submit">Supprimer votre compte<i class="bi bi-trash-fill"></i></button>
        </form>
    <?php endif; ?>
</div>

<?php

$content = ob_get_clean();
$titre = "Compte";
$title = "Compte";
require "commun/template.php";