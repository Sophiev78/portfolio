<?php

session_unset();

ob_start();

?>

Vous avez été deconnecté !

<?php
$content = ob_get_clean();
$titre = "Deconnexion";
$title = "Deconnexion";
require "commun/template.php";