<?php

ob_start();

?>

<?php if(isset($_SESSION["user"]) && $_SESSION["user"]["admin"] == true) : ?>
    <br>
    <div class="container">
        <div class="row mx-auto justify-content-center dashboard">
            <?= "Dashboard = " . $compteur->afficher() . " visisteurs";?>
        </div>
    </div>
    
<?php endif; ?>

<?php

$content = ob_get_clean();
$titre = "Bienvenue sur FVB Store !";
$title = "Accueil";
require "commun/template.php";