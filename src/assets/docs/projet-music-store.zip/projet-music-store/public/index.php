<?php
// Constante de route pour acceder au different parametre du CRUD

define("URL", str_replace("index.php","",(isset($_SERVER["HTTPS"]) ? "https" : "http")."://$_SERVER[HTTP_HOST]$_SERVER[PHP_SELF]"));

/////////////////////////////////////////////////////// Instanciations

//musiques
require "../src/controller/MusiqueController.php";
$musiqueController = new MusiqueController();

//artistes
require "../src/controller/ArtisteController.php";
$artisteController = new ArtisteController();

//categories
require "../src/controller/CategorieController.php";
$categorieController = new CategorieController();

//users
require "../src/controller/UserController.php";
$userController = new UserController();

//panier
require_once "../src/controller/PanierController.php";
$panierController = new PanierController();
$panierController->creationPanier();

require "../src/compteur/compteur.php";
$cpt = new Compteur();

//////////////////////////////////////////////////////// Session

session_start();

// $_SESSION["user"] = ["email" => 'qsdf@qsdf.fr',
//     "password" => "qsdf",
//     "id" => 68,
//     "admin" => false
// ];

// $_POST["email"] = "qsdf@qsdf.fr";
// $_POST["password"] = "qsdf";

// $_SESSION["panier"] = array();
// $_SESSION["panier"]["musiques"] = [new MusiqueEntity(1, "2pac.jpg", "titre", "des", 2,1,1)];
// $_SESSION["panier"]["quantites"] = [3];

// session_unset();
// echo "<pre>";
// print_r($_SESSION);
// echo "</pre>";
// print_r($panierController->getPanierRepository()->getPanierbyUserId(71)->getQuantites())

////////////////////////////////////////////////////// Routeur

// Test Routeur
// $_GET["page"] = 'store';

// print_r($_SESSION);
// echo "cool";

// Routeur fait Maison
try{
    if(empty($_GET['page'])){
        require "views/accueil.php";
    }else{
        $url = explode("/", filter_var($_GET['page']), FILTER_SANITIZE_URL); // Pour securiser les caractères spéciaux dans l'URL (évite les injections)
        switch($url[0]){
            case 'accueil' : 
                require 'views/accueil.php';
                break;
            case 'store' : 
                if(empty($url[1])){
                    $musiqueController->afficherMusiques($artisteController, $categorieController);
                }else{
                    switch($url[1]){

                        // Musiques
                        case "m": // Afficher les musiques
                            $musiqueController->afficherFicheMusique($url[2]);
                            break;
                        case 'a': // Ajouter
                            $musiqueController->ajoutMusique();
                            break;
                        case 'mm': // Modifier
                            $musiqueController->modifMusique($url[2]);
                            break;
                        case 'mmv': // Modifier et valider
                            $musiqueController->modifMusiqueValidation();
                            break;
                        case 's': // Supprimer
                            $musiqueController->suppressionMusique($url[2]);
                            break;
                        case 'av': // Ajouter et valider
                            $musiqueController->ajoutMusiqueValidation();
                            break;
                        case 'ap': // Ajouter panier
                            $panierController->ajoutMusiquePanier($musiqueController, $url[2], 1);
                            break;

                        // crud catégories
                        case 'ac':
                            $categorieController->ajoutCategorie();
                            break;
                        case 'cm':
                            $categorieController->modifCategorie($url[2]);
                            break;
                        case 'cmv':
                            $categorieController->modifCategorieValidation();
                            break;
                        case 'sc':
                            $categorieController->suppressionCategorie($url[2]);
                            break;
                        case 'acv':
                            $categorieController->ajoutCategorieValidation($url[2]);
                            break;

                            // crud artistes
                        case 'aa':
                            $artisteController->ajoutArtiste();
                            break;
                        case 'ma':
                            $artisteController->modifArtiste($url[2]);
                            break;
                        case 'mav':
                            $artisteController->modifArtisteValidation();
                            break;
                        case 'sa':
                            $artisteController->suppressionArtiste($url[2]);
                            break;
                        case 'sav':
                            $artisteController->ajoutArtisteValidation();
                            break;


                        default: // Cas ou L'url n'est pas bonne
                            require "views/404.php";
                            throw new Exception("Cette page n'existe pas !");
                            break; 
                    }
                }
                break;
            case 'connexion' :
                if(empty($url[1])){
                    $userController->afficherConnexion();
                }else{
                    switch($url[1]){
                        case 'a':
                            $statement = $userController->connexion();
                            $userController->connexionValidation($panierController ,$statement);
                            break;
                        default: // Cas ou L'url n'est pas bonne
                            require "views/404.php";
                            throw new Exception("Cette page n'existe pas !");
                            break; 
                    }
                }
                break;
            case 'deconnexion' :
                require 'views/deconnexion.php';
                break;
            case 'panier' :
                if(empty($url[1])){
                    $panierController->afficherPanier();
                }else{
                    switch($url[1]){
                        case 's': // Supression d'un objet d'un panier
                            $panierController->supprimerArticle($url[2]);
                            break;
                    }
                }
                break;
            case 'compte':
                if(empty($url[1])){
                    $userController->modifCompte();
                }else{
                    switch($url[1]){
                        case 'mv':
                            $userController->modifCompteValidation();
                            break;
                        case 's':
                            $userController->suppressionUser();
                            break;
                        default: // Cas ou L'url n'est pas bonne
                            require "views/404.php";
                            throw new Exception("Cette page n'existe pas !");
                            break; 
                    }
                }
                break;
            default:
                require 'views/404.php';
                throw new Exception("Cette page n'existe pas !");
                break;
        }
    }
}catch(Exception $e){
    echo $e->getMessage();
}
