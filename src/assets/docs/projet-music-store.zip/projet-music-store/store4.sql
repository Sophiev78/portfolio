-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 03, 2022 at 04:02 PM
-- Server version: 5.7.24
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `store4`
--
CREATE DATABASE IF NOT EXISTS `store4` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `store4`;

-- --------------------------------------------------------

--
-- Table structure for table `artistes`
--

DROP TABLE IF EXISTS `artistes`;
CREATE TABLE `artistes` (
  `id_artiste` int(11) NOT NULL,
  `nom_artiste` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `artistes`
--

INSERT INTO `artistes` (`id_artiste`, `nom_artiste`) VALUES
(1, 'Tupac'),
(2, '50 cent'),
(3, 'Snoop dog'),
(4, 'The Weeknd'),
(5, 'Chris Brown'),
(6, 'Jason Derulo'),
(7, 'Muse'),
(8, 'Imagine Dragons'),
(9, 'Evanescence'),
(10, 'Martin Garrix'),
(11, 'Tiesto'),
(12, 'Armin Van Buuren'),
(13, 'Alan Walker'),
(14, 'Mamson'),
(15, 'Loïc Nottet');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id_cat` int(11) NOT NULL,
  `nom_cat` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id_cat`, `nom_cat`) VALUES
(1, 'rap'),
(2, 'r\'n\'b'),
(3, 'rock'),
(4, 'electro'),
(5, 'danse');

-- --------------------------------------------------------

--
-- Table structure for table `fait`
--

DROP TABLE IF EXISTS `fait`;
CREATE TABLE `fait` (
  `id_artiste` int(11) NOT NULL,
  `id_musique` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fait`
--

INSERT INTO `fait` (`id_artiste`, `id_musique`) VALUES
(1, 1),
(1, 2),
(1, 3),
(2, 4),
(2, 5),
(2, 6),
(3, 7),
(3, 8),
(3, 9),
(4, 10),
(4, 11),
(4, 12),
(5, 13),
(5, 14),
(5, 15),
(6, 16),
(6, 17),
(6, 18),
(7, 19),
(7, 20),
(7, 21),
(8, 22),
(8, 23),
(8, 24),
(9, 25),
(9, 26),
(9, 27),
(10, 28),
(10, 29),
(10, 30),
(11, 31),
(11, 32),
(11, 33),
(12, 34),
(12, 35),
(12, 36),
(13, 37),
(13, 38),
(13, 39),
(14, 40),
(14, 41),
(14, 42),
(15, 43),
(15, 44),
(15, 45);

-- --------------------------------------------------------

--
-- Table structure for table `musiques`
--

DROP TABLE IF EXISTS `musiques`;
CREATE TABLE `musiques` (
  `id_musique` int(11) NOT NULL,
  `image` varchar(250) NOT NULL,
  `titre` varchar(150) NOT NULL,
  `description` varchar(150) NOT NULL,
  `prix` int(11) NOT NULL,
  `id_cat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `musiques`
--

INSERT INTO `musiques` (`id_musique`, `image`, `titre`, `description`, `prix`, `id_cat`) VALUES
(1, '2pac.jpg', 'Ambitionz Az a Ridah', 'Album All Eyez on Me 2pac', 2, 1),
(2, '2pac.jpg', 'Skandalouz', 'Album All Eyez on Me 2pac', 2, 1),
(3, '2pac.jpg', 'All Bout U', 'Album All Eyez on Me 2pac', 2, 1),
(4, '50cent.jpg', 'Major Distribution', 'Album Street King Immortal', 2, 1),
(5, '50cent.jpg', 'Champions', 'Album Street King Immortal', 2, 1),
(6, '50cent.jpg', 'Get Low', 'Album Street King Immortal', 2, 1),
(7, 'snoop-dogg-.jpg', 'CEO', 'from tha streets 2 tha suites titres snoop dog', 2, 1),
(8, 'snoop-dogg-.jpg', 'Sittin On Blades', 'from tha streets 2 tha suites titres snoop dog', 2, 1),
(9, 'snoop-dogg-.jpg', 'Gang Signs', 'from tha streets 2 tha suites titres snoop dog', 2, 1),
(10, 'theWeeknd.jpg', 'Save Your Tears', 'Album After Hours [explicit]', 2, 2),
(11, 'theWeeknd.jpg', 'Too Late', 'Album After Hours [explicit]', 2, 2),
(12, 'theWeeknd.jpg', 'Blinding Lights', 'Album After Hours [explicit]', 2, 2),
(13, 'ChrisBrown.jpg', 'Come Together', 'Album Indigo [explicit]\r\nChris Brown feat. H.E.R', 2, 2),
(14, 'ChrisBrown.jpg', 'All I Want', 'Album Indigo [explicit]\r\nChris Brown feat. Tyga', 2, 2),
(15, 'ChrisBrown.jpg', 'No Guidance', 'Album Indigo [explicit]\r\nChris Brown feat. Drake', 2, 2),
(16, 'JasonDerulo.jpg', 'Want to Want Me', 'Album everything is 4 [explicit]', 2, 2),
(17, 'JasonDerulo.jpg', 'Get Ugly [explicit]', 'Album everything is 4 [explicit]', 2, 2),
(18, 'JasonDerulo.jpg', 'Cheyenne', 'Album everything is 4 [explicit]\r\n', 2, 2),
(19, 'muse.jpg', 'New Born', 'Album Origin of Symmetry', 2, 3),
(20, 'muse.jpg', 'Darkshines', 'Album Origin of Symmetry', 2, 3),
(21, 'muse.jpg', 'Futurism', 'Album Origin of Symmetry', 2, 3),
(22, 'imagineDragons.png', 'Radioactive', 'Album Night Visions', 2, 3),
(23, 'imagineDragons.png', 'Demons', 'Album Night Visions', 2, 3),
(24, 'imagineDragons.png', 'On Top Of The world', 'imagineDragons.jpg', 2, 3),
(25, 'evanescence.png', 'Missing', 'Album Lost Whispers', 2, 3),
(26, 'evanescence.png', 'Farther Away', 'Album Lost Whispers', 2, 3),
(27, 'evanescence.png', 'If You Don\'t Mind', 'Album Lost Whispers', 2, 3),
(28, 'martinGarrix.png', 'Spotless', 'Album Seven\r\nMartin Garrix & Jay Hardway', 2, 4),
(29, 'martinGarrix.png', 'Welcome', 'Album Seven\r\nMartin Garrix & Julian Jordan', 2, 4),
(30, 'martinGarrix.png', 'Sun Is Never Going Down', 'Album Seven\r\nMartin Garrix feat. Dawn Golden', 2, 4),
(31, 'tiesto.jpg', 'Forever Today', 'Album Just Be', 2, 4),
(32, 'tiesto.jpg', 'Love Comes Again', 'Album Just Be', 2, 4),
(33, 'tiesto.jpg', 'Nyana', 'Album Just Be', 2, 4),
(34, 'arminVanBuuren.jpg', 'Something Real', 'Album Balance [explicit]\r\nArmin Van Burren & Avian Grays feat. Jordan Shaw', 2, 4),
(35, 'arminVanBuuren.jpg', 'Unlove You', 'Album Balance [explicit]\r\nArmin Van Buuren feat. Ne-yo', 2, 4),
(36, 'arminVanBuuren.jpg', 'Million Voices', 'Album Balance [explicit]', 2, 4),
(37, 'alanWalker.jpg', 'Lost Control', 'Album Different World\r\nAlan Walker & Sorana', 2, 5),
(38, 'alanWalker.jpg', 'I Don\'t Wanna Go', 'Album Different World\r\nAlan Walker & Julie Bergan', 2, 5),
(39, 'alanWalker.jpg', 'Do It All for You', 'Album Different World\r\nAlan Walker & Trevor Guthrie', 2, 5),
(40, 'manson.jpg', 'No Reflection', 'Album Born Villain', 2, 5),
(41, 'manson.jpg', 'The Gardener', 'Album Born Villain', 2, 5),
(42, 'manson.jpg', 'Disengaged', 'Album Born Villain', 2, 5),
(43, 'loicNottet.jpg', 'Mud Blood', 'Album Selfcracy [explicit]', 2, 5),
(44, 'loicNottet.jpg', 'Dirty feat. Lil Trip', 'Album Selfcracy [explicit]', 2, 5),
(45, 'loicNottet.jpg', 'Cure', 'Album Selfcracy [explicit]', 2, 5);

-- --------------------------------------------------------

--
-- Table structure for table `panier`
--

DROP TABLE IF EXISTS `panier`;
CREATE TABLE `panier` (
  `id` int(11) NOT NULL,
  `musiques` varchar(5000) NOT NULL,
  `quantites` varchar(5000) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `panier`
--

INSERT INTO `panier` (`id`, `musiques`, `quantites`, `id_user`) VALUES
(6, 'a:0:{}', 'a:0:{}', 4);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `email_user` varchar(150) NOT NULL,
  `pwd_user` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `email_user`, `pwd_user`) VALUES
(1, 'fontaine28210@gmail.com', 'mdp'),
(2, 'sophie@gmail.com', 'pilou'),
(3, 'ines.cdaw.dreux@gmail.com', 'fraulein'),
(4, 'qsdf@qsdf.fr', 'qsdf');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artistes`
--
ALTER TABLE `artistes`
  ADD PRIMARY KEY (`id_artiste`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id_cat`);

--
-- Indexes for table `fait`
--
ALTER TABLE `fait`
  ADD PRIMARY KEY (`id_artiste`,`id_musique`),
  ADD KEY `id_musique` (`id_musique`);

--
-- Indexes for table `musiques`
--
ALTER TABLE `musiques`
  ADD PRIMARY KEY (`id_musique`),
  ADD KEY `id_cat` (`id_cat`);

--
-- Indexes for table `panier`
--
ALTER TABLE `panier`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artistes`
--
ALTER TABLE `artistes`
  MODIFY `id_artiste` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id_cat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `musiques`
--
ALTER TABLE `musiques`
  MODIFY `id_musique` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `panier`
--
ALTER TABLE `panier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `fait`
--
ALTER TABLE `fait`
  ADD CONSTRAINT `fait_ibfk_1` FOREIGN KEY (`id_artiste`) REFERENCES `artistes` (`id_artiste`),
  ADD CONSTRAINT `fait_ibfk_2` FOREIGN KEY (`id_musique`) REFERENCES `musiques` (`id_musique`);

--
-- Constraints for table `musiques`
--
ALTER TABLE `musiques`
  ADD CONSTRAINT `musiques_ibfk_2` FOREIGN KEY (`id_cat`) REFERENCES `categories` (`id_cat`);

--
-- Constraints for table `panier`
--
ALTER TABLE `panier`
  ADD CONSTRAINT `panier_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
